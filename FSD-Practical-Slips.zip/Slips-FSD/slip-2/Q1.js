// Display in Reverse Order
const text3 = "Full Stack!";
const reverseStr = text3.split("").reverse().join("");
console.log(reverseStr);