// Convert to Uppercase
const text1   = "hello world";
const upperStr = text1.toUpperCase();
console.log(upperStr);