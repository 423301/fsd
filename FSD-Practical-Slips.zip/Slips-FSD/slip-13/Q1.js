// Convert to Lowercase
const text2 = "HELLO WORLD";
const lowerStr = text2.toLowerCase();
console.log(lowerStr);